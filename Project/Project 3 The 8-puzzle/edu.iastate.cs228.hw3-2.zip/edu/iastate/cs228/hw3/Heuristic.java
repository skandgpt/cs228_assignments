package edu.iastate.cs228.hw3;

/**
 * 
 * Two heuristics used in solving the 8-puzzle. 
 *
 */
public enum Heuristic 
{
	TileMismatch, ManhattanDist
}
