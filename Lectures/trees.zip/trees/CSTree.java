package trees; 

public class CSTree<E> 
{
	CSNode<E> root;
	int size;
}
