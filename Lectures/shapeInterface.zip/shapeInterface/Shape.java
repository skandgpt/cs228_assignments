// http://www.javabeginner.com/learn-java/java-abstract-class-and-interface

package shapeInterface;

interface Shape 
{
	public double area();
}